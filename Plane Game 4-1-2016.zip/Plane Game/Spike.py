import sys, pygame, math, random

class Spike(pygame.sprite.Sprite):
    pass
