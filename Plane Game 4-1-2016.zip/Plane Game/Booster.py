import sys, pygame, math, random

class Booster(pygame.sprite.Sprite):
    pass
