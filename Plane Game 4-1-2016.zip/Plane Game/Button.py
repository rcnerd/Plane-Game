import sys, pygame, math, random

class Button(pygame.sprite.Sprite):
    pass
