import sys, pygame, math, random
