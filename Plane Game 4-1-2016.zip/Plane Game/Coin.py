import sys, pygame, math, random

class Coin(pygame.sprite.Sprite):
    pass
